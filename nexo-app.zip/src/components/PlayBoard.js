import { Grid, Typography, Paper, Box, Button } from '@material-ui/core'
import { useEffect, useState } from 'react';

import JokenMove from './JokenMove'
import ResultMove from './ResultMove';

const MOVES = ['paper', 'rock', 'scissors']
const RESULTS_TEXTS = ['Empate!', 'Você ganhou!', 'Você perdeu!']

export default function PlayBoard() {
  const [score, setScore] = useState(parseInt(localStorage.getItem('score') || 0))
  const [draws, setDraws] = useState(parseInt(localStorage.getItem('draws') || 0))
  const [loses, setLoses] = useState(parseInt(localStorage.getItem('loses') || 0))

  const [move, setMove] = useState('')
  const [npcMove, setNpcMove] = useState('')
  const [result, setResult] = useState(-1)
  const [showResults, setShowResults] = useState(false)

  function playJoken() {
    if (!move) {
      return
    }
    const playNPC = MOVES[Math.floor(Math.random() * 3)]
    setNpcMove(playNPC)

    if (playNPC === move) {
      setDraws(draws + 1)
      setResult(0)
      localStorage.setItem('draws', draws)
    } else if ((move === 'paper' && playNPC === 'rock') || (move === 'rock' && playNPC === 'scissors') || (move === 'scissors' && playNPC === 'paper')) {
      setScore(score + 1)
      setResult(1)
      localStorage.setItem('score', score)
    } else {
      setLoses(loses + 1)
      setResult(2)
      localStorage.setItem('loses', loses)
    }
  }

  function resetGame () {
    setResult(-1)
    setMove(null)
    setNpcMove(null)
    setShowResults(false)
  }

  useEffect(() => {
    if (result >= 0 && !showResults) {
      setTimeout(() => {
        setShowResults(true)
      }, 3000)
    }
  }, [result, showResults])

  return (
    <Paper elevation={3}>
      <Box p={4}>
        {result >= 0 ? (
          <Box>
            <Grid container>
              <Grid item xs={12}>
                <Typography variant="body1">
                  <b>Resultado</b>
                </Typography>
                {showResults && <Typography variant="h2">
                  {RESULTS_TEXTS[result]}
                </Typography>}
              </Grid>
              <Grid item xs={12}>
                <Box m={4}>
                  <Grid container>
                    <Grid item xs={12} md={6}>
                      <Typography paragraph variant="body2">
                        Sua jogada
                      </Typography>
                      <ResultMove move={move} showMove={showResults} />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography paragraph variant="body2">
                        Jogada do adversário
                      </Typography>
                      <ResultMove move={npcMove} showMove={showResults} />
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
              <Grid xs={12}>
                <Button variant="contained" color="secondary" onClick={() => resetGame()}>
                  Jogar novamente
                </Button>
              </Grid>
            </Grid>
          </Box>
        ) : (
          <Box>
            <Grid container>
              <Grid item xs={12} md={4}>
                <Typography variant="body1">
                  Ganhos: {score}
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography variant="body1">
                  Empates: {draws}
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography variant="body1">
                  Perdidos: {loses}
                </Typography>
              </Grid>
            </Grid>
            <Box my={4}>
              <Grid container>
                {MOVES.map((mov, movIndex) => (<JokenMove key={movIndex} move={mov} isSelected={mov === move} onClick={(mov) => setMove(mov)} />))}
              </Grid>
            </Box>
            <Grid item xs={12}>
              <Button variant="contained" color="primary" onClick={playJoken}>
                Confirmar jogada
              </Button>
            </Grid>
          </Box>
        )
        }
      </Box>
    </Paper>
  )
}