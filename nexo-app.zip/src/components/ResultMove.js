import { Box, Grid } from "@material-ui/core"
// import { useEffect, useState } from "react"
import JokenMove from "./JokenMove"

export default function ResultMove({ move = 'paper', showMove = false }) {
  // const [showMove, setShowMove] = useState(false)

  // useEffect(() => {
  //   setTimeout(() => {
  //     setShowMove(true)
  //   }, 3000)
  // })

  return (
    <Box textAlign="center">
      {showMove ? (
        <Grid container justifyContent="center" className="move-result">
          <JokenMove move={move} />
        </Grid>
      ) : (
        <img src="./circle.png" alt="circle" className="circle-image" />
      )}
    </Box>
  )
}