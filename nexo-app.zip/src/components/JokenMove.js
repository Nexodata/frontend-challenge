import { Grid } from '@material-ui/core'

export default function JokenMove ({ move = 'paper', isSelected = false, onClick = () => {} }) {
  return (
    <Grid item xs={12} md={4} className={`grid-move ${isSelected ? 'selected' : ''}` }>
      <img src={`./icon-${move}.svg`} alt={move} onClick={() => onClick(move)} className="move-image" />
    </Grid>
  )
}