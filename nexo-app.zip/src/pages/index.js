import '../styles/index.css';

import { Grid, Typography } from '@material-ui/core'
import PlayBoard from '../components/PlayBoard';

function App() {
  return (
    <div className="App">
      <Grid container justifyContent="center">
        <Grid item xs={12}>
          <Typography variant="h1" fontSize="24px">
            Jokenpo
          </Typography>
        </Grid>
        <Grid item xs={12} md={7}>
          <PlayBoard />
        </Grid>
      </Grid>
    </div>
  );
}

export default App;
